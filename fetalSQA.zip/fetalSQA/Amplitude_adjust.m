function ecg2 = Amplitude_adjust(ecg1,fs,t_window)
%******************************************************
% $ This function is usded for the amplitude adjustation for filtered ECG waveforms.
%

% Input
% ecg1: original signal
% fs: sample rate
% t_window: ecg signal time window
%
% Output
% ecg2: ecg after amplitude adjustation
%
% $ Author:  Chengyu Liu (chengyu@seu.edu.cn & bestlcy@sdu.edu.cn)
%            Southeast-Lenovo wearable Heart-Sleep-Emotion intelligent monitoring Lab
%            School of Instrument Science and Engineering
%            Southeast University, China
% tidy up: Xiangyu Zhang zhipeng cai
% $Last updated:  2018.5.5

amp_window=0.3;
ecg2=ecg1;
amp_seg=zeros(1,t_window);
for i=1:t_window
    amp_seg(i)=max(ecg2(fs*(i-1)+1:fs*i))-min(ecg2(fs*(i-1)+1:fs*i));
end
amp_seg_sort=sort(amp_seg);
amp_thr=mean(amp_seg_sort(1:3));
num_count=0;
while max(amp_seg)>1.5*amp_thr && num_count<10
    num_count=num_count+1;
    [aa,bb]=max(amp_seg);
    indx_max=find(ecg2(fs*(bb-1)+1:fs*bb)==max(ecg2(fs*(bb-1)+1:fs*bb)))+fs*(bb-1);
    sstart=max(indx_max-round(fs*amp_window),1);
    send=min(indx_max+round(fs*amp_window),length(ecg2));
    ecg2(sstart:send)=ecg2(sstart:send)/1.5;
    for i=1:t_window
        amp_seg(i)=max(ecg2(fs*(i-1)+1:fs*i))-min(ecg2(fs*(i-1)+1:fs*i));
    end
    amp_seg_sort=sort(amp_seg);
    amp_thr=mean(amp_seg_sort(1:3));
end
% ecg2 = filtbyfft(ecg2, fs, [5 35]);
end