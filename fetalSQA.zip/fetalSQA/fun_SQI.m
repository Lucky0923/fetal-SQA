function [sSQI,kSQI,pSQI,basSQI,bsSQI,eSQI,purSQI,enSQI]=fun_SQI(ecg,fs)
    len_sig=length(ecg);
    wind1_QRS_beforeR=0.10*fs;wind1_QRS_afterR=0.10*fs;% QRS window
    len1_qrs=wind1_QRS_beforeR+wind1_QRS_afterR+1;
    wind2_QRS_beforeR=1.00*fs;wind2_QRS_afterR=1.00*fs;% baseline drift window
    len2_qrs=wind2_QRS_beforeR+wind2_QRS_afterR+1;
    % normalize
    
    
    sig_norm=mapminmax(ecg);

    % bSQI
    [~,wqrs_pos,~]=pan_tompkin(sig_norm,fs,0);
    if length(wqrs_pos)<=3
        ecg2 = Amplitude_adjust(ecg,fs,10);
    sig_norm=mapminmax(ecg2);
    end
    [~,wqrs_pos,~]=pan_tompkin(sig_norm,fs,0);
    [~,eqrs_pos,~]=pan_tompkin(sig_norm,fs,0);
    num_wqrs=length(wqrs_pos);
    num_eqrs=length(eqrs_pos);
    num_wqrs_eqrs=0;
    m=1;
    for i=1:num_wqrs
        for j=1:num_eqrs
            if abs(eqrs_pos(j)-wqrs_pos(i))<20
                num_wqrs_eqrs=num_wqrs_eqrs+1;
                common_qrs_pos(m)=wqrs_pos(i);
                m=m+1;
                break;
            end
        end
    end
    num_qrs=m-1;
    per_wqrs=num_qrs/num_wqrs;
    per_eqrs=num_qrs/num_eqrs;
    bSQI=(per_wqrs+per_eqrs)/2;

    % qrs segmentation
    % qrs window is first segmented, qrs can be intercepted from qrs window. The number of qrs window equals the number of qrs
    qrswind=zeros(num_qrs,len2_qrs);
    k_qrs=1;k_qrswind=1;
    for i=1:num_qrs
        R_pos=common_qrs_pos(i);
        if R_pos>wind2_QRS_beforeR&&R_pos<=len_sig-wind2_QRS_afterR
            qrswind(k_qrswind,:)=sig_norm(R_pos-wind2_QRS_beforeR:R_pos+wind2_QRS_afterR);k_qrswind=k_qrswind+1;
    %         figure(1);
    %         plot(qrswind(k_qrswind-1,:));hold on;
        end
    end
    while k_qrswind-1~=num_qrs
        qrswind(k_qrswind,:)=[];
        num_qrs=num_qrs-1;
    end
    qrs=zeros(num_qrs,len1_qrs);% size of qrs should be initialized after num_qrs is reduced
    for i=1:num_qrs
        qrs(k_qrs,:)=qrswind(i,wind2_QRS_beforeR-wind1_QRS_beforeR+1:wind2_QRS_beforeR+wind1_QRS_afterR+1);k_qrs=k_qrs+1;
    end

    % skewness and kurtosis
    sSQI=skewness(sig_norm);
    kSQI=kurtosis(sig_norm);

    % qrs spectral
    fre=(0:len_sig-1)*fs/len_sig;
    spectral_sig=fft(sig_norm,len_sig);
    pow_fre_0to1=0;pow_fre_1to5=0;pow_fre_5to15=0;pow_fre_15to40=0;
    for num=1:len_sig
        if fre(num)>0&&fre(num)<=1
            pow_fre_0to1=pow_fre_0to1+abs(spectral_sig(num))^2;
        else
            if fre(num)>1&&fre(num)<=5
                pow_fre_1to5=pow_fre_1to5+abs(spectral_sig(num))^2;
            else
                if fre(num)>5&&fre(num)<=15
                    pow_fre_5to15=pow_fre_5to15+abs(spectral_sig(num))^2;
                else
                    if fre(num)>15&&fre(num)<=40
                        pow_fre_15to40=pow_fre_15to40+abs(spectral_sig(num))^2;
                    end
                end
            end
        end
    end

    % pSQI basSQI
    pSQI=pow_fre_5to15/(pow_fre_5to15+pow_fre_15to40);
    basSQI=1-pow_fre_0to1/(pow_fre_0to1+pow_fre_1to5+pow_fre_5to15+pow_fre_15to40);

    % bsSQI
    max_qrs=max(qrs,[],2);min_qrs=min(qrs,[],2);
    pk2pk_qrs=max_qrs-min_qrs;
    recons_anawind=zeros(num_qrs,len2_qrs);
    for i=1:num_qrs
        recons_anawind(i,:)=fun_WMRA_12level(qrswind(i,:));
    end
    bw=qrswind-recons_anawind;
    max_bw=max(bw,[],2);min_bw=min(bw,[],2);
    pk2pk_bw=max_bw-min_bw;
    bsSQI=sum(pk2pk_qrs./pk2pk_bw)/num_qrs;

    % eSQI
    energy_qrs=sum(qrs.^2);
    energy_wind=sum(sig_norm.^2);
    eSQI=sum(energy_qrs)/energy_wind;

    % purSQI
    x1=zeros(1,len_sig-1);
    x2=zeros(1,len_sig-2);
    for i=2:len_sig
        x1(i)=sig_norm(i)-sig_norm(i-1);
    end
    for i=2:len_sig-1
        x2(i)=sig_norm(i+1)-2*sig_norm(i)+sig_norm(i-1);
    end
    omega0bar=2*pi/len_sig*sum(sig_norm.^2);
    omega2bar=2*pi/len_sig*sum(x1.^2);
    omega4bar=2*pi/len_sig*sum(x2.^2);
    purSQI=omega2bar^2/omega0bar/omega4bar;
    
    % enSQI
    enSQI=SampEn_fast(sig_norm,2.0,0.15);
    
    % pcaSQI
%     qrs_cov=cov(qrs);
%     [~,qrs_D]=eig(qrs_cov);
%     [size_row,size_col]=size(qrs_D);
%     sum_first5eig=sum(diag(qrs_D(size_row-4:size_row,size_col-4:size_col)));
%     sum_alleig=sum(diag(qrs_D));
%     pcaSQI=sum_first5eig/sum_alleig;
end