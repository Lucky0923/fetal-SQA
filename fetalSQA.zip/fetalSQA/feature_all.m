function [feature_all] = feature_all(ecg)
fs=500;
ecg_original=ecg;
ecg_filt = butthigh(ecg_original,fs);

%%%%%%%%%R��������%%%%%%%%%%%%%%%
% R_peaks=QRS_detection(ecg_filt,fs);
[R_peaks,~,~] = QRS_detection_new(ecg_filt,fs);
x=0;
while length(R_peaks)<=3&&x<=10
    ecg_filt = Amplitude_adjust(ecg_filt,fs,10);
    R_peaks=QRS_detection(ecg_filt,fs);
    x=x+1
end
%%%%%%%%%ģ��ƥ��-R��֮������ϵ������%%%%%%%%%%%%%%%
[ft1] = ft_01(R_peaks,fs,ecg_filt);
[ft2] = ft_02(R_peaks,fs,ecg_filt);
[ft3] = ft_03(R_peaks,fs,ecg_filt);
[ft4] = std(ecg_original);
[ft5] = max(ecg_original)-mean(ecg_original);
[ft6] = mean(ecg_original)-min(ecg_original);
[ft7] = length(ecg_original > mean(ecg_original));
[ft8] = length(ecg_original < mean(ecg_original));
[ft9] = max(ecg_original)-min(ecg_original);
[ft10]= std(diff(ecg_original));

[ft11] = max(ecg_original(R_peaks));
[ft12] = max(ecg_original(R_peaks))- min(ecg_original(R_peaks));
[ft13] = mean(ecg_original(R_peaks))
[ft14]= std( ecg_original(R_peaks));


[sSQI,kSQI,pSQI,basSQI,bsSQI,eSQI,purSQI,enSQI]=fun_SQI(ecg,fs);

feature_all=[ft1,ft2,ft3,ft4,ft5,ft6,ft7,ft8,ft9,ft10,ft11,ft12,ft13,ft14,sSQI,kSQI,pSQI,basSQI,bsSQI,eSQI,purSQI,enSQI];

end

