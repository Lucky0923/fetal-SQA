clc
clear all
close all
%%
a=[];
List =dir('E:\fetal SQA\38������\38������\data segmentation\2019_10_3\data\ecg*.mat');
k =length(List);
for i=1:k
    file_name{i}=List(i).name;
    temp=importdata(file_name{i});
    temp=temp';
    a=[a;temp];
end
path_pri = ['Sig3.mat'];
save(path_pri,'a','-v7.3')
