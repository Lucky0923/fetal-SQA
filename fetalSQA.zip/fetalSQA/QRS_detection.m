function [QRS] = QRS_detection(ecg, fs)
%complete implementation of Pan-Tompkins algorithm

%% Inputs
%ecg: raw ecg vector signal
%fs: sampling frequency
%% Outputs:
%QRS: index of R waves

%% References:
%[1]PAN.J, TOMPKINS. W.J,"A Real-Time QRS Detection Algorithm" IEEE
%TRANSACTIONS ON BIOMEDICAL ENGINEERING, VOL. BME-32, NO. 3, MARCH 1985.
%[2] Hooman Sedghamiz's matlab code

% $ Author:  Chengyu Liu (bestlcy@sdu.edu.cn)
%           Institute of Biomedical Engineering,
%           Shandong University
% $Last updated:  2016.07.20

if ~isvector(ecg)
    error('ecg must be a row or column vector');
end

if nargin<3
    gr = 1; %on default the function always plots
end
ecg = ecg(:); %vectorize
delay = 0;
QRS =[];
qrs_amp_raw=[];

gr=0;

%% Filtering--cancel noise
if fs == 200
    %% Lowpass H(z) = ((1-z^-6)^2)/(1-z^-1)^2
    b = [1 0 0 0 0 0 -2 0 0 0 0 0 1];
    a = [1 -2 1];
    h_l = filter(b, a, [1 zeros(1, 12)]);
    ecg_l = conv(ecg, h_l);
    ecg_l = ecg_l/max(abs(ecg_l));
    delay = 6; %%%%%%%%%THERE IS A QUESTION
    %% highpass filter H(z) = (-1+32z^(-16)+z^(-32))/(1+z^(-1))
    b = zeros(1,33); b(1) = -1; b(17) = 32; b(33) = 1;
    a = [1 -1];
    h_h = filter(b, a, [1 zeros(1, 32)]);
    ecg_h = conv(ecg_l, h_h);
    ecg_h = ecg_h/max(abs(ecg_h));
    delay = delay+16; %%%%%%%%%%THERE IS A QUESTION
else
    %% bandpass filter for other sampling frequencies 
    f1 = 5; %cutoff low frequecy to get rid of baseline wander
    f2 = 15; %cutoff frequency to discard high frequency noise
    Wn = [f1 f2]*2/fs;
    N = 3;
    [a, b] = butter(N, Wn);
    ecg_h = filtfilt(a, b, ecg);
    ecg_h = ecg_h/max(abs(ecg_h));
    %%%%%%%%%THERE IS A QUESTION: WHAT ABOUT THE DELAY???
end


%% derivative filter H(z) = (1/8T)(-z^-2 - 2z^-1 +2z +z^2)
h_d = [-1 -2 0 2 1]*(1/8);
ecg_d = conv(ecg_h, h_d);
ecg_d = ecg_d/max(abs(ecg_d));
delay = delay+2; %%%%%%%%%THERE IS A QUESTION


%% Squaring nonlinearly enhance the dominant peaks
ecg_s = ecg_d.^2;%%%%%%WHAT ABOUT DELAY??


%% Moving Average (150ms)
ecg_m = conv(ecg_s ,ones(1 ,round(0.150*fs))/round(0.150*fs));
delay = delay+15;




%% use mamic as fiducial mark
% Note : a minimum distance of 40 samples is considered between each R wave
% since in physiological point of view no RR wave can occur in less than
% 200 msec distance
[pks, locs] = findpeaks(ecg_m, 'MINPEAKDISTANCE', round(0.2*fs));

%% initialize the training phase(2s of the signal) to determine the THR_SIG
%%and THR_NOISE
THR_SIG = max(ecg_m(1:2*fs))*1/3; %0.25 of the max amplitude
THR_NOISE = mean(ecg_m(1:2*fs))*1/2; % 0.5 of the mean signal is consider to be noise
SIG_LEV = THR_SIG;
NOISE_LEV= THR_NOISE;
%initialize bandpass filter threshold
THR_SIG1 = max(ecg_h(1:2*fs))*1/3; % 0.25 of the max amplitude
THR_NOISE1 = max(ecg_h(1:2*fs))*1/2;
SIG_LEV1 = THR_SIG1;
NOISE_LEV1 = THR_NOISE1;


%%for RR 
mean_RR = 0; %the most_recent RR interval
mean1_RR_buf = [];
mean1_RR = 0; % the most recent RR interval that fell between the acceptable low and high RR_interval limits
selected_RR = 0;
%%variable
skip = 0;

%%%variable for observe
qrs_c = [];
qrs_i = [];
noise_c = [];
noise_i = [];
SIGL_buf = [];
NOISL_buf = [];
THRS_buf = [];
SIGL_buf1 = [];
NOISL_buf1 = [];
THRS_buf1 = [];


for i = 1:length(pks)
     
%% locate the corresponding peak in the filtered signal
    if locs(i)-round(0.15*fs)>=1 && locs(i)<=length(ecg_h)
        [y_i, x_i] = max(ecg_h(locs(i)-round(0.15*fs):locs(i))); %QRS complex interval:150ms
        x_i = locs(i)-round(0.15*fs)+(x_i-1);
    elseif i==1
        [y_i, x_i] = max(ecg_h(1:locs(i)));
    elseif locs(i)>=length(ecg_h)
        [y_i, x_i] = max(ecg_h(locs(i)-round(0.15*fs):end));
        x_i = locs(i)-round(0.15*fs)+(x_i-1);
    end
%% adjust the RR
  
   if length(qrs_c)==9
        diffRR= diff(qrs_i(end-8:end)); %calculate RR interval
        mean_RR = mean(diffRR); % calculate the mean of 8 previous RR interval
        mean1_RR=mean_RR;
        mean1_RR_buf=diffRR;
   end
   if length(qrs_c)>9
        current_RR = locs(i)-qrs_i(end);
        if current_RR>=0.92*mean1_RR && current_RR <=1.16*mean1_RR
            mean1_RR_buf = [mean1_RR_buf(2:8) current_RR];
            mean1_RR = mean(mean1_RR_buf);
        
        elseif current_RR<=0.92*mean1_RR || current_RR >=1.16*mean1_RR
            %irregular RR interval,first threahold reduced by half to
            %increase sensitivity
            THR_SIG = 0.5*THR_SIG;
            THR_SIG1 = 0.5*THR_SIG1;
        end
        %% % make sure QRS is not missing 1.66*mean
         if current_RR>=round(1.66*mean1_RR)  
            [pks_temp, locs_temp] = max(ecg_m(qrs_i(end)+round(0.2*fs):locs(i)-round(0.2*fs)));
            locs_temp = qrs_i(end)+round(0.2*fs)+locs_temp-1; %location
            
                if locs_temp <=length(ecg_h)
                       [y_i_temp, x_i_temp] = max(ecg_h(locs_temp-round(0.15*fs):locs_temp));
                else
                        [y_i_temp, x_i_temp] = max(ecg_h(locs_temp-round(0.15*fs):end));

                end
                         x_i_temp = locs_temp-round(0.15*fs)+(x_i_temp-1);
            
            
         %serach back's threshold is half of THR_SIG equals to THR_NOISE
                      if pks_temp>0.5*THR_SIG %%at search back, threshold reduced
                                      qrs_c = [qrs_c pks_temp];
                                      qrs_i = [qrs_i locs_temp];
                                      QRS_miss=1;  %ͨ��searchback �ҵ���ʧ�˵�һ����ֵ
                                       %pks_temp is nnot noise, and not T wave update threshold
                                       SIG_LEV = 0.25*pks_temp+0.75*SIG_LEV;
                                      
                                    %take care of bandpass signal threshold
                                        if y_i_temp>THR_NOISE1
                                            QRS = [QRS x_i_temp];
                                            qrs_amp_raw = [qrs_amp_raw y_i_temp];
                                            %we make sure this is next R wave
                                            SIG_LEV1 = 0.25*y_i_temp+0.75*SIG_LEV1;
                                        end
                
%                      %find the location in filtered sig
                     end
%                   end %otherwise, we ignore it, that's to say we think donnot have missing QRS
         end %otherwise, we neednot search back.
   end

    
    %% find noise and QRS peaks
    if pks(i)>=THR_SIG
        %is T wave? is noise?
        if length(qrs_c)>=3
            if(locs(i)-qrs_i(end))<=round(0.36*fs)
                slope1 = mean(diff(ecg_m(locs(i)-round(0.075*fs):locs(i))));%mean slope of the waveform at that position
                slope2 = mean(diff(ecg_m(qrs_i(end)-round(0.075*fs):qrs_i(end))));%mean slope of previous R wave 
                if abs(slope1)<=abs(0.5*slope2)
                    noise_c = [noise_c pks(i)];
                    noise_i = [noise_i locs(i)];
                    skip = 1; % T wave identification
                    %adjust noise level
                    NOISE_LEV1 = 0.125*y_i+0.875*NOISE_LEV1;
                    NOISE_LEV = 0.125*pks(i)+0.875*NOISE_LEV;
                else
                    skip = 0;
                end
            end
        end % at begin, we havenot enough message to evaluate meanRR , so we think it not T wave
        
        if skip==0
            qrs_c = [qrs_c pks(i)];
            qrs_i = [qrs_i locs(i)];
            SIG_LEV = 0.125*pks(i)+0.875*SIG_LEV;
            
            if y_i>=THR_SIG1
                QRS = [QRS x_i];
                qrs_amp_raw = [qrs_amp_raw y_i];
                SIG_LEV1 = 0.125*y_i+0.875*SIG_LEV1;
            end
        end
        %%
    elseif THR_NOISE<=pks(i) && pks(i)<THR_SIG
        NOISE_LEV1 = 0.125*y_i+0.875*NOISE_LEV1;
        NOISE_LEV = 0.125*pks(i)+0.875*NOISE_LEV;
    elseif pks(i)<THR_NOISE
        noise_c = [noise_c pks(i)];
        noise_i = [noise_i locs(i)];
        NOISE_LEV1 = 0.125*y_i+0.875*NOISE_LEV1;
        NOISE_LEV = 0.125*pks(i)+0.875*NOISE_LEV;
    end
    
    
    %% adjust the threshold with SNR
    if NOISE_LEV~=0||SIG_LEV1~=0
        THR_SIG = NOISE_LEV + 0.25*(abs(SIG_LEV-NOISE_LEV));
        THR_NOISE = 0.5*THR_SIG;
    end
    if NOISE_LEV1 ~= 0 || SIG_LEV1 ~= 0
        THR_SIG1 = NOISE_LEV1 + 0.25*(abs(SIG_LEV1 - NOISE_LEV1));
        THR_NOISE1 = 0.5*(THR_SIG1);
    end
    
    
%%
    
    
    %take a track of thresholds
    SIGL_buf = [SIGL_buf SIG_LEV];
    NOISL_buf = [NOISL_buf NOISE_LEV];
    THRS_buf = [THRS_buf THR_SIG];
    SIGL_buf1 = [SIGL_buf1 SIG_LEV1];
    NOISL_buf1 = [NOISL_buf1 NOISE_LEV1];
    THRS_buf1 = [THRS_buf1 THR_SIG1];
    
    %reset parameters
    skip = 0;
end


%% plot
if gr
 if fs == 200
  figure,  ax(1)=subplot(321);plot(ecg);axis tight;title('Raw ECG Signal');
  ax(2)=subplot(322);plot(ecg_l);axis tight;title('Low pass filtered');
  ax(3)=subplot(323);plot(ecg_h);axis tight;title('High Pass Filtered');
 else
  figure,  ax(1)=subplot(3,2,[1 2]);plot(ecg);axis tight;title('Raw ECG Signal');
  ax(3)=subplot(323);plot(ecg_h);axis tight;title('Band Pass Filtered'); 
 end
 ax(4)=subplot(324);plot(ecg_d);axis tight;title('Filtered with the derivative filter');
 ax(5)=subplot(325);plot(ecg_s);axis tight;title('Squared');
 ax(6)=subplot(326);plot(ecg_m);axis tight;title('Averaged with 30 samples length,Black noise,Green Adaptive Threshold,RED Sig Level,Red circles QRS adaptive threshold');
 axis tight;
 
 
 hold on,scatter(qrs_i,qrs_c,'m');
 hold on,plot(locs,NOISL_buf,'--k','LineWidth',2);
 hold on,plot(locs,SIGL_buf,'--r','LineWidth',2);
 hold on,plot(locs,THRS_buf,'--g','LineWidth',2);
 if ax(:)
     linkaxes(ax,'x');
     zoom on;
 end
 
 
 figure,az(1)=subplot(311);plot(ecg_h);title('QRS on Filtered Signal');axis tight;
 hold on,scatter(QRS,qrs_amp_raw,'m');
 hold on,plot(locs,NOISL_buf1,'LineWidth',2,'Linestyle','--','color','k');
 hold on,plot(locs,SIGL_buf1,'LineWidth',2,'Linestyle','-.','color','r');
 hold on,plot(locs,THRS_buf1,'LineWidth',2,'Linestyle','-.','color','g');
 az(2)=subplot(312);plot(ecg_m);title('QRS on MVI signal and Noise level(black),Signal Level (red) and Adaptive Threshold(green)');axis tight;
 hold on,scatter(qrs_i,qrs_c,'m');
 hold on,plot(locs,NOISL_buf,'LineWidth',2,'Linestyle','--','color','k');
 hold on,plot(locs,SIGL_buf,'LineWidth',2,'Linestyle','-.','color','r');
 hold on,plot(locs,THRS_buf,'LineWidth',2,'Linestyle','-.','color','g');
 az(3)=subplot(313);plot(ecg-mean(ecg));title('Pulse train of the found QRS on ECG signal');axis tight;
 line(repmat(QRS,[2 1]),repmat([min(ecg-mean(ecg))/2; max(ecg-mean(ecg))/2],size(QRS)),'LineWidth',2.5,'LineStyle','-.','Color','r');
 linkaxes(az,'x');
 zoom on;
 
 figure, plot(ecg);axis tight;title('Raw ECG Signal');
hold on,
plot(QRS,ecg(QRS),'ro');
hold off
figure, plot(ecg_h);axis tight;title('filted ECG Signal');
hold on,
plot(QRS,ecg_h(QRS),'ro');
hold off

end

end