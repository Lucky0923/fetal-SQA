 load('ecg1')
 fs=500; len_sig=length(ecg);
 sig_norm=mapminmax(ecg);
% qrs spectral
    fre=(0:len_sig-1)*fs/len_sig;
    spectral_sig=fft(sig_norm,len_sig);
    pow_fre_0to1=0;pow_fre_1to5=0;pow_fre_5to15=0;pow_fre_15to40=0;
    for num=1:len_sig
        if fre(num)>0&&fre(num)<=1
            pow_fre_0to1=pow_fre_0to1+abs(spectral_sig(num))^2;
        else
            if fre(num)>1&&fre(num)<=5
                pow_fre_1to5=pow_fre_1to5+abs(spectral_sig(num))^2;
            else
                if fre(num)>5&&fre(num)<=15
                    pow_fre_5to15=pow_fre_5to15+abs(spectral_sig(num))^2;
                else
                    if fre(num)>15&&fre(num)<=40
                        pow_fre_15to40=pow_fre_15to40+abs(spectral_sig(num))^2;
                    end
                end
            end
        end
    end

    % pSQI basSQI
    pSQI=pow_fre_5to15/(pow_fre_5to15+pow_fre_15to40);
    basSQI=1-pow_fre_0to1/(pow_fre_0to1+pow_fre_1to5+pow_fre_5to15+pow_fre_15to40);