function [ft2] = ft_02(R_peaks,fs,ecg_filt)
try
[cov_sum,~]= cov_template(R_peaks,fs,ecg_filt,0.03);
ft2=mean(cov_sum);
catch
    ft2=0.9;
end
end

