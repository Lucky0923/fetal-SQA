function [cov_sum, cov ]= cov_template(R_peaks,fs,ecg_filt,template_time)
        R_template=R_peaks(2:end-1);
        template_num=length(R_template);
        template_length=floor(template_time*fs);
        for  u=1:template_num
            template(1:2*template_length+1,u)=ecg_filt(R_template(u)-template_length:template_length+R_template(u));
        end


         for y1=1:template_num
            for y2=1:template_num
             cov(y1,y2) =corr(template(1:2*template_length+1,y1),template(1:2*template_length+1,y2),'type','Spearman');
            end
           cov_su(y1)=sum(cov(y1,:));
        end
     cov_sum=cov_su(1:template_num) /template_num;
% 
%      
%             mark_size=5;
%             figure('color','w');
%             plot((1:length(ecg_filt))/fs,ecg_filt,'b');
%             hold on
%            
%             hold on
%             plot(R_peaks/fs,ecg_filt(R_peaks),'o','MarkerSize',mark_size,'MarkerEdgeColor','k','MarkerFaceColor','k');
%             hold on
%           plot( R_template/fs,cov_sum,'-o','MarkerSize',mark_size,'MarkerEdgeColor','k','MarkerFaceColor','k');
        
end

