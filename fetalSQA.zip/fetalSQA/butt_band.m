function [ecg1] = butt_band(ecg,fs)
wp=1;
ws=0.5;
Rp=0.3;
Rs=2;
[N1,Wn1]=buttord(wp/(fs/2),ws/(fs/2),Rp,Rs);
[b1,a1]=butter(N1,Wn1,'high');
ecg1 = filtfilt(b1, a1, ecg);
wp=40;
ws=43;
Rp=0.3;
Rs=2;
[N1,Wn1]=buttord(wp/(fs/2),ws/(fs/2),Rp,Rs);
[b1,a1]=butter(N1,Wn1,'low');
ecg1 = filtfilt(b1, a1, ecg1);
end

