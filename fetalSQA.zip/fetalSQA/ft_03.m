function [ft3] = ft_03(R_peaks,fs,ecg_filt)
try
[cov_sum,~]= cov_template(R_peaks,fs,ecg_filt,0.12);
ft3=mean(cov_sum);
catch
    ft3=0.8;
end
end
