% This function is compute hurst exponent value
function [hus]= hurst(xV)
% xV is the signal data
n=length(xV);
d=[];
len=[];
y=xV;
y2=cumsum(y-mean(y),1);
d(1)=mean(range(y2)./std(y,1));
i=1;
len(1)=size(y,1);
while size(y,1)>=16
    i=i+1;
    rnr=floor(n/(2^(i-1)));
    rnc=floor(n/rnr);
    y=reshape(xV(1:rnr*rnc),rnr,rnc);
    n2=size(y,1);
    pop=find(std(y,1)~=0);     %
    if ~isempty(pop)
        y=y(:,pop);                %
        len(i)=n2;
        y2=cumsum(y-kron(mean(y),ones(n2,1)),1);
        d(i)=mean(range(y2)./std(y,1));
    else
        len(i) = NaN;
        d(i)=NaN;
    end
end
dlog=log2(d(end:-1:1));
blog=log2(len(end:-1:1));
pone=polyfit(blog,dlog,1);
hus=pone(1);