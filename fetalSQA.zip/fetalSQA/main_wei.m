



load('E:\̥����������\38������\Sig3.mat')

fs=500;
ecg=a;
% ecg=ecg(1,:);
% % [feature_wei] = Copy_of_feature_36(ecg,fs)

for i=1:150
    i
    ecg_N= normalize(ecg,2)

    % newfeatures function will return the extracted feature values
    feature_wei(i,:)=feature(ecg_N(i,:),fs);
   
end
save feature_wei.mat feature_wei

