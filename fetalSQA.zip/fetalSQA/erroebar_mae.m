clear all
close all
x = [1:10];
y = sin(x);
err = rand(1,10);
errorbar(x,y,err,'both','o','linewidth',1.5)
% set(gca,'looseInset',[0 0 0 0]) %ȥ������ױ�
axis equal