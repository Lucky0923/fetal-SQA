function [ft1] = ft_01(R_peaks,fs,ecg_filt)
try
[cov_sum,cov]= cov_template(R_peaks,fs,ecg_filt,0.012);
ft1=mean(cov_sum);
catch
    ft1=0.8;
end
end

